
from django.urls import path

from .api import theaterApi,theaterCreateApi,theaterUpdateApi,theaterDeleteApi




urlpatterns = [
    path('api/',theaterApi.as_view()),
    path('api/create/',theaterCreateApi.as_view()),
    path('api/<int:pk>',theaterUpdateApi.as_view()),
    path('api/delete/<int:pk>',theaterDeleteApi.as_view()),


]
