
from pyexpat import model
from rest_framework import serializers

from .models import theater


class theaterSerializer(serializers.ModelSerializer):
    class Meta:
        model=theater
        fields='__all__'