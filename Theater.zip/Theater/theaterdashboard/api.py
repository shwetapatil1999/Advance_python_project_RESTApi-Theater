from rest_framework import generics
from rest_framework.response import Response
from .serializer import theaterSerializer
from .models import theater


class theaterCreateApi(generics.CreateAPIView):
    queryset = theater.objects.all()
    serializer_class = theaterSerializer

class theaterApi(generics.ListAPIView):
    queryset = theater.objects.all()
    serializer_class = theaterSerializer

class theaterUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = theater.objects.all()
    serializer_class = theaterSerializer

class theaterDeleteApi(generics.DestroyAPIView):
    queryset = theater.objects.all()
    serializer_class = theaterSerializer

