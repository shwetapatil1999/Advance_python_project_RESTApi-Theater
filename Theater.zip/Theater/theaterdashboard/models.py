from django.db import models

# Create your models here.
class theater(models.Model):
    movie_name=models.CharField(max_length=250)
    user_name=models.CharField(max_length=250)
    booking=models.IntegerField()
    date=models.CharField(max_length=250)
    price=models.IntegerField(max_length=250)
    description=models.TextField(max_length=250)

    